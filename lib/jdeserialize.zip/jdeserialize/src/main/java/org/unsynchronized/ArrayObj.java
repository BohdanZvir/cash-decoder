package org.unsynchronized;

/**
 * <p>Represents an array Instance, including the values the comprise the array.  </p>
 *
 * <p>Note that in arrays of primitives, the ClassDesc will be named "[x", where x is the
 * Field type code representing the primitive type.  See JDeserialize.resolveJavaType()
 * for an example of analysis/generation of human-readable names from these class names.</p>
 */
public class ArrayObj extends ContentBase {
    /**
     * Type of the array Instance.
     */
    public ClassDesc classDesc;

    /**
     * Values of the array, in the order they were read from the stream.
     */
    public ArrayColl data;

    public ArrayObj(int handle, ClassDesc cd, ArrayColl data) {
        super(ContentType.ARRAY);
        this.handle = handle;
        this.classDesc = cd;
        this.data = data;
    }
    public String toString() {
        return "[array " + JDeserialize.hex(handle) + " ClassDesc " + classDesc.toString() + ": "
            + data.toString() + "]";
    }
}

