package org.unsynchronized.testcases;

import java.io.Serializable;

public class Blob implements Serializable {
    public class Inner implements Serializable {
        private int ia;
        private String ib;
        public Inner(int ia, String ib) {
            this.ia = ia;
            this.ib = ib;
        }
        public String toString() {
            return "[Inner ia " + ia + "  ib " + ib + "]";
        }
    }
    private int a;
    private String b;
    private Inner i;

    public String toString() {
        return "[Blob a " + a + "  b " + b + "  i " + i.toString() + "]";
    }

    public Blob(int a, String b) {
        this.a = a;
        this.b = b;
        this.i = new Inner(a+1, b);
    }
}
