package org.unsynchronized;

public enum ContentType {
    INSTANCE, CLASS, ARRAY, STRING, ENUM, CLASSDESC, BLOCKDATA, EXCEPTIONSTATE
}
