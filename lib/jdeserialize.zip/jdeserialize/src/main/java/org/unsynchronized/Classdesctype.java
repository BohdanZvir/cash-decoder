package org.unsynchronized;

/**
 * Enum for class description types.
 */
public enum Classdesctype {
    NORMALCLASS, PROXYCLASS
}
