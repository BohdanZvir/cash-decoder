package org.unsynchronized;
import java.util.*;

/**
 * Represents an Instance of a non-enum, non-Class, non-ObjectStreamClass,
 * non-array class, including the non-transient Field values, for all classes in its
 * hierarchy and Inner classes.
 */
public class Instance extends ContentBase {
    /**
     * Collection of Field data, organized by class description.
     */
    public Map<ClassDesc, Map<Field, Object>> fielddata;

    /**
     * Class description for this Instance.
     */
    public ClassDesc classDesc;

    /**
     * Constructor.
     */
    public Instance() {
        super(ContentType.INSTANCE);
        this.fielddata = new HashMap<ClassDesc, Map<Field, Object>>();
    }
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append(classDesc.name).append(' ').append("_h").append(JDeserialize.hex(handle))
            .append(" = r_").append(JDeserialize.hex(classDesc.handle)).append(";  ");
        //sb.append("// [Instance " + JDeserialize.hex(handle) + ": " + JDeserialize.hex(ClassDesc.handle) + "/" + ClassDesc.name).append("]");
        return sb.toString();
    }
    /**
     * Object annotation data.
     */
    public Map<ClassDesc, List<Content>> annotations;
}
