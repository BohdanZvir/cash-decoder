package org.unsynchronized;

/**
 * This represents a Class object (i.e. an Instance of type Class) serialized in the
 * stream.
 */
public class ClassObj extends ContentBase {
    /**
     * The class description, including its name.
     */
    public ClassDesc classDesc;

    /**
     * Constructor.
     *
     * @param handle the Instance's handle
     * @param cd the Instance's class description
     */
    public ClassObj(int handle, ClassDesc cd) {
        super(ContentType.CLASS);
        this.handle = handle;
        this.classDesc = cd;
    }
    public String toString() {
        return "[class " + JDeserialize.hex(handle) + ": " + classDesc.toString() + "]";
    }
}

