import java.util.*;
import java.io.*;

public enum Benum {
    VALUEA, VALUEB, VALUEC, VALUED, VALUE,
}
